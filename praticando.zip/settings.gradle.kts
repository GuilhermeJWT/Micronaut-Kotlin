
rootProject.name="praticando"
